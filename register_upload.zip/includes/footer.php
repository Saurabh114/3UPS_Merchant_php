 <!-- Start app Footer part -->
 <footer class="main-footer">
     <div class="footer-left">
         <div class="bullet"></div>
         3UPS &copy; <?php echo date("Y"); ?>. All Rights Reserved | Designed & Developed by
         <i id="fico" class="fa fa-cube" aria-hidden="true"></i>
         <a href="https://www.hspmsolutions.com/" style="text-decoration:none;">HSPM Solutions LLP. </a>
     </div>
     <div class="footer-right">

     </div>
 </footer>
 </div>
 </div>

 <!-- General JS Scripts -->
 <script src="assets/bundles/lib.vendor.bundle.js"></script>
 <script src="js/CodiePie.js"></script>

 <!-- JS Libraies -->
 <script src="assets/modules/jquery.sparkline.min.js"></script>
 <script src="assets/modules/chart.min.js"></script>
 <script src="assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
 <script src="assets/modules/summernote/summernote-bs4.js"></script>
 <script src="assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

 <!-- Page Specific JS File -->
 <script src="js/page/index.js"></script>

 <!-- Template JS File -->
 <script src="js/scripts.js"></script>
 <script src="js/custom.js"></script>


 <!-- JS Libraies -->
 <script src="assets/modules/jquery-selectric/jquery.selectric.min.js"></script>
 <script src="assets/modules/upload-preview/assets/js/jquery.uploadPreview.min.js"></script>
 <script src="assets/modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
 <script src="assets/modules/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
 <script src="assets/modules/prism/prism.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>

 <!-- Page Specific JS File -->
 <script src="js/page/features-post-create.js"></script>